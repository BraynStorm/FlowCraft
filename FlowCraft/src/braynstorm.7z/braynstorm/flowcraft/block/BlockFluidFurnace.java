package braynstorm.flowcraft.block;

import java.util.Random;

import braynstorm.flowcraft.FlowCraft;
import braynstorm.flowcraft.libs.Data;
import braynstorm.flowcraft.tile.TileEntityLiquidFurance;
import cpw.mods.fml.common.network.FMLNetworkHandler;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class BlockFluidFurnace extends BlockContainer{
	
	private final boolean isActive;
	private static boolean keepInventory;
	
	@SideOnly(Side.CLIENT)
	public Icon iconFront, iconTop, iconSide;
	
	public BlockFluidFurnace(int id, boolean isActive) {
		super(id, Material.iron);
		
		this.isActive = isActive;
		
		if(isActive)
			this.setHardness(4.5F)
			.setUnlocalizedName(Data.stringBlockLiquidFurnaceActive)
			.setLightValue(Data.blockLiquidFurnaceLightLevel);
			//.setTextureName(Data.MOD_ID + ":" + "liquidFurnaceActiveSide");
		else
			this.setHardness(3.5F)
			.setCreativeTab(CreativeTabs.tabBlock)
			.setUnlocalizedName(Data.stringBlockLiquidFurnaceIdle);
			//.setTextureName(Data.MOD_ID + ":" + "liquidFurnaceIdleSide");
		
		System.out.println(this.getUnlocalizedName());
			
	}
	
	public static void updateState(boolean state, World world, int x, int y, int z){
		int i = world.getBlockMetadata(x, y, z);
		TileEntity tile = world.getBlockTileEntity(x, y, z);
		keepInventory = true;
		
		if(state){
			world.setBlock(x, y, z, FlowCraft.blockFluidFurnaceActive.blockID);
		}else{
			world.setBlock(x, y, z, FlowCraft.blockFluidFurnaceIdle.blockID);
		}
		
		keepInventory = false;
		
		world.setBlockMetadataWithNotify(x, y, z, i, 2);
		
		if(tile != null){
			tile.validate();
			world.setBlockTileEntity(x, y, z, tile);
		}
		
	}
	
	@Override
	public boolean hasComparatorInputOverride(){
		return true;
		
	}
	
	@Override
	public int getComparatorInputOverride(World world,int x,int y, int z, int i){
		return net.minecraft.inventory.Container.calcRedstoneFromInventory((IInventory)world.getBlockTileEntity(x, y, z));
	}
	
	@Override
	public int idPicked(World world,int x, int y, int z){
		return FlowCraft.blockFluidFurnaceIdle.blockID;
	}
	
	
	
	
	
	
	@SideOnly(Side.CLIENT)
	public void registerIcons(IconRegister iconRegister){
		this.blockIcon = iconRegister.registerIcon(Data.MOD_ID + ":" + (this.isActive ? FlowCraft.blockFluidFurnaceActive.getUnlocalizedName() + "Side"  : FlowCraft.blockFluidFurnaceIdle.getUnlocalizedName() + "Side" ));
		this.iconTop   = iconRegister.registerIcon(Data.MOD_ID + ":" + (this.isActive ? FlowCraft.blockFluidFurnaceActive.getUnlocalizedName() + "Top"   : FlowCraft.blockFluidFurnaceIdle.getUnlocalizedName() + "Top"  ));
		this.iconFront = iconRegister.registerIcon(Data.MOD_ID + ":" + (this.isActive ? FlowCraft.blockFluidFurnaceActive.getUnlocalizedName() + "Front" : FlowCraft.blockFluidFurnaceIdle.getUnlocalizedName() + "Front"));
		
		this.iconSide = this.blockIcon;
	}
	
	@SideOnly(Side.CLIENT)
	public Icon getIcon (int side, int metadata){
		if(side == metadata)
			return this.iconFront;
		if(side == 1 || side == 0)
			return this.iconTop;
		return this.iconSide;
	}
	
	@Override
	public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ){
		
		if(!world.isRemote){
			//if(player.getItemInUse().itemID == Item.bucketLava.itemID){
			//	player.setItemInUse(new ItemStack(Item.bucketEmpty), 1);
			//	System.out.println("The Liquid Furnace was filled with Lava.");
			//}else{
				FMLNetworkHandler.openGui(player, FlowCraft.instance, Data.guiIdLiquidFurnace, world, x, y, z);
			//}
		}
		
		
		return true;
	}
	
	
	@Override
	public TileEntity createNewTileEntity(World world) {
		return new TileEntityLiquidFurance();
	}
	
	
	public int idDropped(int par1, Random random, int par3){
		return FlowCraft.blockFluidFurnaceIdle.blockID;
	}
	
	
	// Adds sided textures
	@Override
	public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack itemStack){
		
		int a = MathHelper.floor_double((double)(entity.rotationYaw * 4.0F / 360.0F) + 0.5D) & 3;
		
		if(a == 0)
			world.setBlockMetadataWithNotify(x, y, z, 2, 2);
		if(a == 1)
			world.setBlockMetadataWithNotify(x, y, z, 5, 2);
		if(a == 2)
			world.setBlockMetadataWithNotify(x, y, z, 3, 2);
		if(a == 3)
			world.setBlockMetadataWithNotify(x, y, z, 4, 2);
		
		if(itemStack.hasDisplayName()){
			((TileEntityLiquidFurance)world.getBlockTileEntity(x, y, z)).setGuiDisplayName(itemStack.getDisplayName());
		}
		
	}
	
	public void onBlockAdded(World world, int x, int y, int z){
		
		super.onBlockAdded(world, x, y, z);
		this.setDefaultDirection(world, x, y, z);
	}
	
	private void setDefaultDirection(World world, int x, int y, int z){
		
		if(world.isRemote)
			return;
		
		/* North = z - 1
		 * South = z + 1
		 * East  = x + 1
		 * West  = x - 1
		 * */
		 
		
		int a = world.getBlockId(x, y, z - 1), // North
			b = world.getBlockId(x, y, z + 1), // South
			c = world.getBlockId(x - 1, y, z), // West
			d = world.getBlockId(x + 1, y, z); // East
		
		byte b0 = 3;
		
		if(Block.opaqueCubeLookup[a] && !Block.opaqueCubeLookup[b])
			b0 = 3;
		if(Block.opaqueCubeLookup[b] && !Block.opaqueCubeLookup[a])
			b0 = 2;
		if(Block.opaqueCubeLookup[d] && !Block.opaqueCubeLookup[c])
			b0 = 5;
		if(Block.opaqueCubeLookup[c] && !Block.opaqueCubeLookup[d])
			b0 = 4;
		
		
		
		world.setBlockMetadataWithNotify(x, y, z, b0, 2);
		
	}
	
	
	
	
	
	
	
	
	
	
}
