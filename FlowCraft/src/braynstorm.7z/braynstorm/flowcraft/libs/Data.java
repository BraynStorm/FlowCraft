package braynstorm.flowcraft.libs;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;

public class Data {
	public static final String MOD_ID     = "flowcraft";
	public static final String MOD_NAME   = "FlowCraft";
	public static final String VERSION    = "0.0.1";
	
	public static final int idBlockLiquidFuranceIdle       = 3000; 
	public static final int idBlockLiquidFuranceActive     = 3001;
	
	public static final String stringBlockLiquidFurnaceIdle    = "blockLiquidFuranceIdle"; 
	public static final String stringBlockLiquidFurnaceActive  = "blockLiquidFuranceActive";
	
	public static final String nameBlockLiquidFurnace      = "Liquid Furnace";
	public static final String nameTileEntityLiquidFurnace = "tileEntityLiquidFurnace";
	
	
	public static final String guiLiquidFurnacePath = "textures/gui/liquidFurnaceGui.png";
	
	public static final int guiIdLiquidFurnace 			   = 0;
	public static final int blockLiquidFurnaceLightLevel   = 13;
	public static final int tankLiquidFuranceCapacity	   = 2000;
	
}
