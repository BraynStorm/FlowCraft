package braynstorm.flowcraft.libs;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;

public class Registry {

	public static void registerBlock(Block block, String string, String name){
		GameRegistry.registerBlock(block, string);
		LanguageRegistry.addName(block, name);
	}
	
	public static void registerItem(Item item, String string, String name){
		GameRegistry.registerItem(item, string);
		LanguageRegistry.addName(item, name);
	}
	
}
