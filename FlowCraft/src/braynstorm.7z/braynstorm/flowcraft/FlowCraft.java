package braynstorm.flowcraft;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.fluids.FluidRegistry;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.network.NetworkMod;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;
import braynstorm.flowcraft.block.BlockFluidFurnace;
import braynstorm.flowcraft.gui.GuiHandler;
import braynstorm.flowcraft.libs.Data;
import braynstorm.flowcraft.libs.Registry;
import braynstorm.flowcraft.recipes.RecipeRegistry;
import braynstorm.flowcraft.tile.TileEntityLiquidFurance;


@Mod(modid = Data.MOD_ID, name = Data.MOD_NAME, version = Data.VERSION)
@NetworkMod(clientSideRequired = true, serverSideRequired = true)
public class FlowCraft {
	
	public static Block blockFluidFurnaceIdle;
	public static Block blockFluidFurnaceActive;
	
	@Instance(Data.MOD_ID)
	public static FlowCraft instance;
	
	
	@EventHandler
	public void preInit(FMLPreInitializationEvent e){
		// Liquids...
		
		
	}
	
	@EventHandler
	public void init(FMLInitializationEvent e){
		// Everything else...
		
		blockFluidFurnaceIdle = new BlockFluidFurnace(Data.idBlockLiquidFuranceIdle, false);
		blockFluidFurnaceActive = new BlockFluidFurnace(Data.idBlockLiquidFuranceActive, true);
		
		GameRegistry.registerTileEntity(TileEntityLiquidFurance.class, Data.nameTileEntityLiquidFurnace);
		
		Registry.registerBlock(blockFluidFurnaceIdle, Data.stringBlockLiquidFurnaceIdle, Data.nameBlockLiquidFurnace);
		Registry.registerBlock(blockFluidFurnaceActive, Data.stringBlockLiquidFurnaceActive, Data.nameBlockLiquidFurnace);
		
		NetworkRegistry.instance().registerGuiHandler(this, new GuiHandler());
		
		RecipeRegistry.registerLiquidFurnaceFluid(FluidRegistry.LAVA, 200, 10);
		
		LanguageRegistry.instance().addStringLocalization("container.liquidFurance", Data.nameBlockLiquidFurnace);
	}
	
	@EventHandler
	public void postInit(FMLPostInitializationEvent e){
		// Buckets and stuff
		
		
		
		
	}
	
}
