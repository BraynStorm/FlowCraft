package braynstorm.flowcraft.gui;

import org.lwjgl.opengl.GL11;

import braynstorm.flowcraft.gui.invntory.ContainerLiquidFurnace;
import braynstorm.flowcraft.libs.Data;
import braynstorm.flowcraft.tile.TileEntityLiquidFurance;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;

public class GuiLiquidFurnace extends GuiContainer {
	
	public static final ResourceLocation texture = new ResourceLocation(Data.MOD_ID, Data.guiLiquidFurnacePath);
	
	private TileEntityLiquidFurance liquidFurnace;
	
	public GuiLiquidFurnace(InventoryPlayer inventoryPlayer, TileEntityLiquidFurance entity) {
		super(new ContainerLiquidFurnace(inventoryPlayer, entity));
		
		this.liquidFurnace = entity;
		
		this.xSize = 176;
		this.ySize = 200;
	}
	
	public void drawGuiContainerForegroundLayer(int a, int b){
		
		//func_135053_a
		
		String name = this.liquidFurnace.isInvNameLocalized() ? this.liquidFurnace.getInvName() : I18n.getString(this.liquidFurnace.getInvName());
		this.fontRenderer.drawString(name, this.xSize / 2 - this.fontRenderer.getStringWidth(name) / 2 , 5, 4210752);
		this.fontRenderer.drawString(I18n.getString("container.inventory"), 8, this.ySize - 107, 4210752);
	}

	@Override
	public void drawGuiContainerBackgroundLayer(float f, int i, int j) {
		GL11.glColor4f(1F,1F,1F,1F);
		
		Minecraft.getMinecraft().getTextureManager().bindTexture(texture);
		
		drawTexturedModalRect(guiLeft, guiTop, 0, 0, xSize, ySize);
		
	}
	
}
