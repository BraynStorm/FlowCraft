package braynstorm.flowcraft.gui.invntory;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import braynstorm.flowcraft.tile.TileEntityLiquidFurance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.Slot;
import net.minecraft.inventory.SlotFurnace;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;

public class ContainerLiquidFurnace extends Container {
	
	private TileEntityLiquidFurance liquidFurnace;
	
	public int lastBurnTime,lastCookTime;
	
	public ContainerLiquidFurnace(InventoryPlayer inventory, TileEntityLiquidFurance tile){
		
		this.liquidFurnace = tile;
		
		// Slot Registration
		this.addSlotToContainer(new Slot (tile, 0, 30, 10));
		this.addSlotToContainer(new Slot (tile, 1, 30, 26));
		this.addSlotToContainer(new Slot (tile, 2, 30, 42));
		this.addSlotToContainer(new Slot (tile, 3, 30, 58));
		
		this.addSlotToContainer(new SlotFurnace(inventory.player, tile, 4, 114, 36));
		
		int id = 0;
		for(int i = 0; i < 3; i++){
			for(int j = 0; j < 9; j++){
				this.addSlotToContainer(new Slot (inventory, id, 8 + 18 * j, 118 + 18 * i));
				id++;
			}
		}
		
		for(int i = 0; i < 9; i++){
			this.addSlotToContainer(new Slot (inventory, id, 8 + 18 * i, 176));
			id++;
		}
	}
	
	public void addCraftingToCrafters(ICrafting icrafting){
		super.addCraftingToCrafters(icrafting);
		icrafting.sendProgressBarUpdate(this, 0, this.liquidFurnace.cookTime);
		
		icrafting.sendProgressBarUpdate(this, 4, this.liquidFurnace.cookTime);
	}
	
	public void detectAndSendChanges(){
		super.detectAndSendChanges();
		//TODO Hi
	}
	
	@SideOnly(Side.CLIENT)
	public void updateProgressBars(int slot, int newTime){
		if(slot == 0)
			this.liquidFurnace.cookTime = newTime;
	}
	@Override
	public ItemStack transferStackInSlot(EntityPlayer player, int slot){
		
		
		return null;
	}
	
	@Override
	public boolean canInteractWith(EntityPlayer entityplayer) {
		return this.liquidFurnace.isUseableByPlayer(entityplayer);
	}

}
