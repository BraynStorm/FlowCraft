package braynstorm.flowcraft.gui;

import braynstorm.flowcraft.FlowCraft;
import braynstorm.flowcraft.gui.invntory.ContainerLiquidFurnace;
import braynstorm.flowcraft.libs.Data;
import braynstorm.flowcraft.tile.TileEntityLiquidFurance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import cpw.mods.fml.common.network.IGuiHandler;
import cpw.mods.fml.common.network.NetworkRegistry;

public class GuiHandler implements IGuiHandler {
	
	@Override
	public Object getServerGuiElement(int ID, EntityPlayer player, World world,	int x, int y, int z) {
		
		TileEntity entity = world.getBlockTileEntity(x, y, z);
			
		if(entity != null){
				
			switch(ID){
				
				// Liquid Furnace GUI
				case Data.guiIdLiquidFurnace:
						
					if(entity instanceof TileEntityLiquidFurance){
						return new ContainerLiquidFurnace(player.inventory, (TileEntityLiquidFurance) entity);
					}
					break;
			}
		}
		return null;
	}

	@Override
	public Object getClientGuiElement(int ID, EntityPlayer player, World world,	int x, int y, int z) {
		
		TileEntity entity = world.getBlockTileEntity(x, y, z);
		
		if(entity != null){
			
			switch(ID){
			
				// Liquid Furnace GUI
				case Data.guiIdLiquidFurnace:
					if(entity instanceof TileEntityLiquidFurance){
						return new GuiLiquidFurnace(player.inventory, (TileEntityLiquidFurance) entity);
					}
					break;
			}
			
		}
		return null;
	}
	
}
