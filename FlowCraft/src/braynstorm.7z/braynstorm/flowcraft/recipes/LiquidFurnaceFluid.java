package braynstorm.flowcraft.recipes;

import net.minecraftforge.fluids.Fluid;

public class LiquidFurnaceFluid {
	
	public int amountPerOperation;
	public Fluid fluid;
	public int speed;
	
	
	public LiquidFurnaceFluid(Fluid fluid, int speed, int amountPerOperation) {
		this.speed = speed;
		this.fluid = fluid;
		this.amountPerOperation = amountPerOperation;
	}	
}
