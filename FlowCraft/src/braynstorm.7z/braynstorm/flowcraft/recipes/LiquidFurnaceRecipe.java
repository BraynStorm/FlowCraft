package braynstorm.flowcraft.recipes;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.FluidStack;

public class LiquidFurnaceRecipe {
	public ItemStack item1, item2, item3, item4, outputItem;
	public float time;
	
	public LiquidFurnaceRecipe(ItemStack item1, ItemStack item2, ItemStack item3, ItemStack item4 ,ItemStack outputItem, float time){
		this.item1 = item1;
		this.item2 = item2;
		this.item3 = item3;
		this.item4 = item4;
		this.outputItem = outputItem;
		this.time = time;
	}
}
