package braynstorm.flowcraft.recipes;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidRegistry;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.oredict.OreDictionary;

public class RecipeRegistry {
	
	private static List<LiquidFurnaceRecipe> liquidFuranceRecipe = new ArrayList<LiquidFurnaceRecipe>();
	private static List<LiquidFurnaceFluid> liquidFurnaceFluid = new ArrayList<LiquidFurnaceFluid>();
	
	/*
	 * @param recipe = A Liquid Furnace recipe
	 */
	public static boolean liquidFurnaceRecipeHasRecipe(LiquidFurnaceRecipe recipe){
		if(liquidFuranceRecipe.contains(recipe))
			return true;
		
		for(LiquidFurnaceRecipe addedRecipe : liquidFuranceRecipe){
			// CHecks if the input items are the same (all of them) and if the input items aren't the same as the output(IdiotProof).
			if((	OreDictionary.itemMatches(addedRecipe.item1, recipe.item1, false)		&&
					OreDictionary.itemMatches(addedRecipe.item2, recipe.item2, false) 		&&
					OreDictionary.itemMatches(addedRecipe.item3, recipe.item3, false) 		&&
					OreDictionary.itemMatches(addedRecipe.item4, recipe.item4, false)) 		||
					OreDictionary.itemMatches(addedRecipe.item1, recipe.outputItem, false) 	||
					OreDictionary.itemMatches(addedRecipe.item2, recipe.outputItem, false)	||
					OreDictionary.itemMatches(addedRecipe.item3, recipe.outputItem, false) 	||
					OreDictionary.itemMatches(addedRecipe.item4, recipe.outputItem, false)	||
					recipe.item1.equals(addedRecipe.item1)									||
					recipe.item2.equals(addedRecipe.item2)									||
					recipe.item3.equals(addedRecipe.item3)									||
					recipe.item4.equals(addedRecipe.item4)									||
					recipe.item1.equals(addedRecipe.outputItem)								||
					recipe.item2.equals(addedRecipe.outputItem)								||
					recipe.item3.equals(addedRecipe.outputItem)								||
					recipe.item4.equals(addedRecipe.outputItem)
					)
				return true;
		}
		
		return false;
		
	}
	public static boolean liquidFurnaceLiquidHasFluid(Fluid fluidRecipe){
		
		for(LiquidFurnaceFluid addedFluid : liquidFurnaceFluid)
			if(FluidRegistry.getFluid(addedFluid.fluid.getID()).equals(FluidRegistry.getFluid(fluidRecipe.getID())))
					return true;
		return false;
		
	}
	
	/* 
	 * @return	Returns TRUE if the recipe has been added, FALSE if the recipe has already been added
	 */
	public static boolean registerLiquidFurnaceRecipe(ItemStack item1,ItemStack item2,ItemStack item3,ItemStack item4, ItemStack outputItem, float time){
		LiquidFurnaceRecipe r = new LiquidFurnaceRecipe(item1, item2, item3, item4, outputItem, time);
		if (!liquidFurnaceRecipeHasRecipe(r)){
			liquidFuranceRecipe.add(r);
			return true;
		}
		return false;
	}
	
	public static boolean registerLiquidFurnaceFluid(Fluid fluid, int speed, int amountPerOperation){
		LiquidFurnaceFluid f = new LiquidFurnaceFluid(fluid, speed, amountPerOperation);
		if(!liquidFurnaceLiquidHasFluid(f.fluid)){
			liquidFurnaceFluid.add(f);
			return true;
		}

		return false;
	}
	
	
	public static LiquidFurnaceFluid getFluidRecipe(Fluid fluid){
		
		for(LiquidFurnaceFluid recipe : liquidFurnaceFluid){
			if(recipe.fluid.getID() == fluid.getID())
				return recipe;
		}
		
		return null;
		
	}
	
	public static LiquidFurnaceRecipe getRecipe(ItemStack item1,ItemStack item2,ItemStack item3,ItemStack item4){
		
		for(LiquidFurnaceRecipe recipe : liquidFuranceRecipe){
			if(((	OreDictionary.itemMatches(recipe.item1, item1, false) && 
					OreDictionary.itemMatches(recipe.item2, item2, false) &&
					OreDictionary.itemMatches(recipe.item3, item3, false) &&
					OreDictionary.itemMatches(recipe.item4, item4, false)
				) || (
				recipe.item1.itemID == item1.itemID &&
				recipe.item2.itemID == item2.itemID &&
				recipe.item3.itemID == item3.itemID &&
				recipe.item4.itemID == item4.itemID
				)) && (
					item1.stackSize >= recipe.item1.stackSize &&
					item2.stackSize >= recipe.item2.stackSize &&
					item3.stackSize >= recipe.item3.stackSize &&
					item4.stackSize >= recipe.item4.stackSize 
				))
				return recipe;
		}
		
		return null;
		
	}
	
}










