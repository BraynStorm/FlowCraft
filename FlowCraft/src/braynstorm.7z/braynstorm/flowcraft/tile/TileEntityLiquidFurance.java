package braynstorm.flowcraft.tile;

import braynstorm.flowcraft.block.BlockFluidFurnace;
import braynstorm.flowcraft.libs.Data;
import braynstorm.flowcraft.recipes.LiquidFurnaceFluid;
import braynstorm.flowcraft.recipes.LiquidFurnaceRecipe;
import braynstorm.flowcraft.recipes.RecipeRegistry;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidTankInfo;
import net.minecraftforge.fluids.IFluidTank;

public class TileEntityLiquidFurance extends TileEntity implements ISidedInventory, IFluidTank{
	
	/*
	 * Idea : a alloy furnace that uses a liquid to smelt and the different liquids have different speeds
	 * 
	 */
	
	
	private static final int[] slots_top = new int[]    {0,1,2,3};
	private static final int[] slots_sides = new int[]  {4,0,1,2,3};
	private static final int[] slots_bottom = new int[] {4};
	
	private FluidStack fuel = null;
	private LiquidFurnaceFluid fuelRecipe = null;
	
	
	
	private String localizedName;
	
	private ItemStack[] slots = new ItemStack[5];
	private LiquidFurnaceRecipe currentRecipe = null;
	
	private boolean isBurning;
	
	// Time left for burning , The speed of the furnace, The curren Burn Time for this amount (sip) of liquid
	public int cookTime,speed;
	
	
	@Override
	public void updateEntity(){
		boolean isWorkingFlag = false;
		
		if(this.worldObj.isRemote){
			if(this.canBurn()){
				this.startCooking();
			}
			
			if(this.isBurning()){
				isWorkingFlag = true;
				this.cookTime++;
				
				if(this.cookTime == this.speed){
					this.cookTime = 0;
					this.smeltItem();
				}
			}
			//this.fuel.amount -= this.fuelRecipe.amountPerOperation;
			BlockFluidFurnace.updateState(this.cookTime > 0 , this.worldObj, this.xCoord, this.yCoord, this.zCoord);
			
		}
		
		if(isWorkingFlag)
			this.onInventoryChanged();
	}

	
	private void startCooking(){
		this.cookTime = 0;
		this.isBurning = true;
	}
	
	private void smeltItem() {
		if(this.slots[4].itemID == this.currentRecipe.outputItem.itemID || this.slots[4].stackSize >= this.slots[4].getMaxStackSize()){
			this.slots[0] = new ItemStack(this.slots[0].getItem(), this.slots[0].stackSize - this.currentRecipe.item1.stackSize);
			this.slots[1] = new ItemStack(this.slots[1].getItem(), this.slots[1].stackSize - this.currentRecipe.item2.stackSize);
			this.slots[2] = new ItemStack(this.slots[2].getItem(), this.slots[3].stackSize - this.currentRecipe.item3.stackSize);
			this.slots[3] = new ItemStack(this.slots[3].getItem(), this.slots[2].stackSize - this.currentRecipe.item4.stackSize);
		
			this.slots[4] = new ItemStack(this.slots[4].getItem(), this.slots[4].stackSize + this.currentRecipe.outputItem.stackSize);
			
			if(this.slots[0].stackSize <= 0)
				this.slots[0] = null;
			if(this.slots[1].stackSize <= 0)
				this.slots[1] = null;
			if(this.slots[2].stackSize <= 0)
				this.slots[2] = null;
			if(this.slots[3].stackSize <= 0)
				this.slots[4] = null;
			
		}
	}

	private boolean isBurning() {
		return this.cookTime > 0;
	}

	private boolean canBurn() {
		//this.fuel.amount >= fuelRecipe.amountPerOperation &&
		//&& this.currentRecipe != null 
		//if(this.fuel.amount >= this.fuelRecipe.amountPerOperation )
			//return true;
		return true;
	}
	public int getSizeInventory (){
		return this.slots.length;
	}

	public void setGuiDisplayName(String displayName) {
		this.localizedName = displayName;
	}
	
	public boolean isInvNameLocalized(){
		return !(this.localizedName == null || this.localizedName == "");
	}

	public String getInvName() {
		return this.isInvNameLocalized() ? this.localizedName : "container.liquidFurnace";
	}
	
	public boolean isItemInRecipe(ItemStack itemstack){
		return false;
	}

	@Override
	public ItemStack getStackInSlot(int slot) {
		return this.slots[slot];
	}

	@Override
	public ItemStack decrStackSize(int slot, int amount) {
		if(this.slots[slot] != null){
			ItemStack stack;
			if(this.slots[slot].stackSize <= amount){
				
				stack = this.slots[slot].copy();
				this.slots[slot] = null;
			}else{
				stack = this.slots[slot].splitStack(amount);
				
				if(this.slots[slot].stackSize <= 0){
					this.slots[slot] = null;
				}
			}
			return stack;
		}
		return null;
	}

	@Override
	public ItemStack getStackInSlotOnClosing(int slot) {
		if(this.slots[slot] != null){
			ItemStack stack = this.slots[slot];
			this.slots[slot] = null;
			return stack;
		}
		return null;
	}

	@Override
	public void setInventorySlotContents(int slot, ItemStack itemstack) {
		this.slots[slot] = itemstack;
		
		if(itemstack != null && itemstack.stackSize > getInventoryStackLimit()){
			itemstack.stackSize = this.getInventoryStackLimit();
		}
		
		this.currentRecipe = RecipeRegistry.getRecipe(slots[0], slots[1], slots[2], slots[3]);
	}

	@Override
	public int getInventoryStackLimit() {
		return 64;
	}

	@Override
	public boolean isUseableByPlayer(EntityPlayer entityplayer) {
		return this.worldObj.getBlockTileEntity(this.xCoord, this.yCoord, this.zCoord) != this
				? false : entityplayer.getDistanceSq((double) this.xCoord + 0.5D,(double)this.yCoord + 0.5D, (double)this.zCoord + 0.5D) <= 64.0D;
	}

	@Override
	public void openChest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void closeChest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isItemValidForSlot(int slot, ItemStack itemstack) {
		return slot == 4 ? false : this.isItemInRecipe(itemstack);
	}

	@Override
	public int[] getAccessibleSlotsFromSide(int side) {
		return side == 0 ? this.slots_bottom : side == 1 ? this.slots_top : this.slots_sides;
	}

	@Override
	public boolean canInsertItem(int slot, ItemStack itemstack, int side) {
		return this.isItemValidForSlot(slot, itemstack);
	}

	@Override
	public boolean canExtractItem(int slot, ItemStack itemstack, int side) {
		return slot == 5;
	}

	
	// Tank Stuff
	@Override
	public FluidStack getFluid() {
		return this.fuel;
	}

	@Override
	public int getFluidAmount() {
		return this.fuel.amount;
	}

	@Override
	public int getCapacity() {
		return Data.tankLiquidFuranceCapacity;
	}

	@Override
	public FluidTankInfo getInfo() {
		return new FluidTankInfo(this);
	}

	@Override
	public int fill(FluidStack resource, boolean doFill) {
		if(doFill) this.fuel.amount = this.fuel.amount + resource.amount > this.getCapacity() ? this.getCapacity() : resource.amount;
		fuelRecipe = RecipeRegistry.getFluidRecipe(resource.getFluid());
		return this.fuel.amount;
	}

	@Override
	public FluidStack drain(int maxDrain, boolean doDrain) {
		int afterDrain = this.fuel.amount - maxDrain;
		if(doDrain) this.fuel.amount = afterDrain >= 0 ? afterDrain : this.fuel.amount;
		return this.fuel;
		
	}
	
}
